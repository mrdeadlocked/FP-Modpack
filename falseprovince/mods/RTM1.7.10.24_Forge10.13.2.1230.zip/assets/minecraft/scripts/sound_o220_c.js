function onUpdate(){
	var maxSp = 72;
	var speed = su.getSpeed();
	var notch = su.getNotch();
	
	if(notch == 0){
		su.stopSound('rtm', 'train.tsurikake');
	}else{
		if(speed > 0.0){
			su.stopSound('rtm', 'train.223_air');
			//var v0 = speed / maxSp;
			//var pitch = (v0 / Math.sqrt(1.0 + v0 * v0)) * 3.0 + 1.0;
			//su.playSound('rtm', 'train.tsurikake', 1.0, pitch);
			
			if(speed >= 36){
				su.stopSound('rtm', 'train.tsurikake');
				//var pitch = (v0 / Math.sqrt(1.0 + v0 * v0)) + 1.0;
				var pitch0 = sigmoid((speed - 36) / 36);
				su.playSound('rtm', 'train.tsurikake_x2', 1.0, pitch0);
			}else{
				su.stopSound('rtm', 'train.tsurikake_x2');
				var pitch1 = sigmoid(speed / 36);
				su.playSound('rtm', 'train.tsurikake', 1.0, pitch1);
			}

			if(speed >= 12.0){
				var vol = (speed - 12.0) / (maxSp - 12.0);
				if(su.inTunnel()){
					su.playSound('rtm', 'train.223_run_tunnel', vol, 1.0);
				}else{
					su.stopSound('rtm', 'train.223_run_tunnel');
				}
			}else{
				su.stopSound('rtm', 'train.223_run_tunnel');
			}
		}else{
			su.playSound('rtm', 'train.223_air', 1.0, 1.0);
			su.stopSound('rtm', 'train.tsurikake');
			su.stopSound('rtm', 'train.tsurikake_x2');
		}
	}
}

function sigmoid(p1){
	return (p1 / Math.sqrt(1.0 + p1 * p1)) + 1.0;
}
